
public class Operacao {
    
    
double resultado,valor1,valor2;

public double somar (double valor1, double valor2){
resultado=valor1+valor2;
return resultado; }

public double subtrair (double valor1, double valor2){
resultado=valor1-valor2;
return resultado; }

public double multiplicar (double valor1, double valor2){
resultado=valor1*valor2;
return resultado; }

public double dividir (double valor1, double valor2){
resultado=valor1/valor2;
return resultado; }

}