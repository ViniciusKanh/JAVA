/******************************************************************************

Criar uma classe que simula uma calculadora de 4 operações (soma, subtração, multiplicação e divisão),
calculando dois números fornecidos pelo usuário e exibindo o resultado quando solicitado
*******************************************************************************/
import javax.swing.JOptionPane;
import java.util.Scanner;


public class Main {

   
    public static void main(String[] args) {
        
    Operacao op = new Operacao();
    Scanner ent = new Scanner (System.in);
    
    int opc;
    
    System.out.println("Digite o Primeiro Valor");
    op.valor1 =  ent.nextDouble();
    System.out.println("Digite o Sugundo Valor");
    op.valor2 =  ent.nextDouble();
    
      System.out.println("Escolha uma das Operacoes abaixo \n");
       System.out.println("1. SOMAR");
       System.out.println("2. SUBTRAIR");
       System.out.println("3. MULTIPLICAR");
       System.out.println("4. DIVIDIR");
     opc =  ent.nextInt();
    
    switch (opc) {
     case 1:
       op.somar(op.valor1,op.valor2);
      System.out.println(" A Soma de : "+op.valor1+" + "+op.valor2+" e = " +op.resultado );
       break;
     case 2:
              op.subtrair(op.valor1,op.valor2);
      System.out.println(" A Subtracao de : "+op.valor1+" - "+op.valor2+" e = " +op.resultado );
       break;
     case 3:
              op.multiplicar(op.valor1,op.valor2);
      System.out.println(" A Multiplicacao de : "+op.valor1+" X "+op.valor2+" e = " +op.resultado );
       break;
     case 4:
                  op.dividir(op.valor1,op.valor2);
      System.out.println(" A Divisao de : "+op.valor1+" / "+op.valor2+" e = " +op.resultado );
       break;
     default:
       System.out.println("Opcao inválido");
  }
    

}

}
