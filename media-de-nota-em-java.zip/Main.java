/******************************************************************************

Aluno:Vinicius de Souza Santos

*******************************************************************************/
import java.util.Scanner;
public class Main


{
	public static void main(String[] args) {
	 Scanner ent = new Scanner(System.in);
int nota1, nota2;
int media, i, contAluno = 0;
	 
for(i = 0; i < 2; i++){
            contAluno++;
// recebe a 1º nota
System.out.println("Aluno " + contAluno + ", digite sua 1ª nota");
            nota1 = ent.nextInt();
// recebe a 2º nota
System.out.println("Aluno " + contAluno + ", digite sua 2ª nota");
            nota2 = ent.nextInt();
// calcula a média
            media = (nota1 + nota2 ) / 2;
System.out.println("A média do aluno " + contAluno + " é " + media);
// mostra a nota do aluno
if( (media >= 0) && (media <7) ){
System.out.println("Reprovado");
            } else if(media >= 7 && media<9){
System.out.println("Aprovado");
            } else if(media == 10){
System.out.println("Aprovado com distincao");

            }
        }       
    }
		
		
		
	}

