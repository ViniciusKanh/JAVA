/******************************************************************************

Crie uma classe chamada Retângulo contendo a base e a altura. 
Crie 3 métodos: um para calcular a área; o outro para calcular o perímetro e um outro
para retornar os valores da base e da altura.

*******************************************************************************/
import java.util.Scanner;

public class Retangulo {

	private static float largura;
	private static float altura;

	public float getLargura() {
		return largura;
	}

	public boolean setLargura(float largura) {

		if ((largura < 0.0) || (largura > 20.0)) {
			System.out.println("numero invalido");
			return false;
		} else {
			this.largura = largura;
			return true;
		}
	}

	public float getAltura() {
		return altura;
	}

	public boolean setAltura(float altura) {

		if ((altura < 0.0) || (altura > 20.0)) {
			System.out.println("numero invalido");
			return false;
			

		} else {
			this.altura = altura;
			return true;
		}
	}

	public float perimetro() {
		float p = 2 * (largura + altura);
		return p;
	}

	public float area() {
		float a = (largura * altura);
		return a;
	}

}
