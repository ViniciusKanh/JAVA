/******************************************************************************

Crie uma classe chamada Retângulo contendo a base e a altura. 
Crie 3 métodos: um para calcular a área; o outro para calcular o perímetro e um outro
para retornar os valores da base e da altura.

*******************************************************************************/
import java.util.Scanner;

public class Main {
    
	public static void main(String args[]) {
	    
	    float altura,largura;
	   Retangulo oj = new Retangulo();    
        Scanner entrada = new Scanner(System.in);    
        System.out.print("altura:");    
        oj.setAltura(entrada.nextFloat());    
        System.out.print("largura:");    
       oj.setLargura(entrada.nextFloat());    
        System.out.print("perimetro : " + oj.perimetro() + " area :"    
                + oj.area());   

	}

}
