/******************************************************************************

Escreva uma classe Quadrado,com atributos lado, area e perimetro e,os mC)todos calcular Area,calcular Perimetro e imprimir
.Os mC)todos calcular Area e calcular Perimetro devem efetuar seus respectivos cC!lculos e colocar os valores nos atributos 
area e perimetro.O mC)todo imprimir deve retornar os valores de todos os atributos.
Salienta - se que a C!rea de um quadrado C) obtida pela fC3rmula ( lado * lado) e o perC-metro por (4*lado).

*******************************************************************************/
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
       
        Quadrado q = new Quadrado();
                q.construtor();
                q.imprimir();
               
    }
}


