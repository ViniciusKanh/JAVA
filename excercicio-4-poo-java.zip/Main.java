/******************************************************************************

Faça um programa que carregue um vetor de 15 elementos inteiros diferentes digitados pelo usuário. 
Apresente o vetor ordenado e depois verifique a existência de elemento também digitado pelo usuário, 
mostrando a posição em que esse elemento aparece. Se não existir o elemento no vetor, apresentar uma mensagem

*******************************************************************************/
import java.util.Scanner;
import java.util.Arrays;

public class Main
{
  public static void main (String[]args)
  {
    Scanner ent = new Scanner (System.in);

    int vet[] = new int[16];
   

    int i, media=0,altura=0;

	System.out.println ("Digite abaixo os valores:");
    for (i = 0; i <=15;i++)
      {
       //Arrays.sort(vet);
	vet[i] = ent.nextInt ();
int indice = Arrays.binarySearch(vet,i);
      }
      	System.out.println ("\n");
	System.out.println ("Mostrando Vaixo os Valores digitados pelo o usuario");
	   	System.out.println ("\n");
	
    for (i = 0; i <=15;i++)
      {
      Arrays.sort(vet);
	System.out.println ("Vetor["+i+"] = "+vet[i]);
	
      }

  }

}
