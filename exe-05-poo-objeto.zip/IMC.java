public class IMC
{

  float peso;
  float altura;
  int imc;

  float CalculoImc (float peso, float altura)
  {

    float imc;
      this.altura = this.altura * this.altura;
      imc = this.peso / this.altura;

      return imc;

  }

  void imprimir (String NomePessoa, float imc)
  {

    System.out.println ("********************************");

    System.out.println ("Ola Sr(a): " + NomePessoa +
			" O valor do seu IMC e: " + imc);

    System.out.println ("********************************");

    if (imc <= 20){
      System.out.println ("Magro");
  }
  else if (imc < 20 && imc <= 24)
  {
    System.out.println ("Normal");
  }
else if (imc > 24 && imc <= 29)
  {
    System.out.println ("Acima do peso");
  }
else if (imc > 29 && imc <= 34)
  {
    System.out.println ("Obeso");
  }
else if (imc > 34)
  {
    System.out.println ("Muito Obeso");

  }
}
}
