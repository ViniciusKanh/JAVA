/******************************************************************************

Criar uma classe Paciente com o nome, o peso e a altura. A classe deve conter os seguintes mC)todos: 
calcular IMC, classificar IMC e imprimir Dados. Cadastrar um paciente e testar todos os mC)todos criados.
*******************************************************************************/
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Main
{

  public static void main (String args[])
  {
    Scanner ent = new Scanner (System.in);
    IMC a = new IMC ();
    Paciente b = new Paciente();
    Float peso, altura, imc;
    
     System.out.println ("Digite seu Nome");
      b.NomePessoa = ent.nextLine ();
      System.out.println ("Digite o Peso");
      b.peso = ent.nextFloat ();
      System.out.println ("Digite a Altura");
      b.altura = ent.nextFloat ();

      a.CalculoImc (b.peso, b.altura);
      
      a.imprimir(b.NomePessoa,a.imc);





  }
}


