/******************************************************************************

Criar uma classe Paciente com o nome, o peso e a altura. A classe deve conter os seguintes métodos: 
calcular IMC, classificar IMC e imprimir Dados. Cadastrar um paciente e testar todos os métodos criados.

*******************************************************************************/

public class Paciente {

	String NomePessoa;
	int idade;
	float altura;
	float peso;
	String sexo;	
	
	public String getNome(){
		return NomePessoa;
	}

	public int getIdade(){
		return idade;
	}
	
	public float getAltura(){
		return altura;
	}
	
	public float getPeso(){
		return peso;
	}
	
	public String getSexo(){
		return sexo;
	}

}


