import javax.swing.JOptionPane;
public class IMC {

public int CalculoImc(int peso, int altura){

int imc;
imc=peso/(altura*altura);
return imc;

}
}