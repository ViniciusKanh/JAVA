/******************************************************************************

Aluno:Vinicius de Souza Santos
Prontuario:BI3008061
Instituicao Federal de Sao Paulo Campus Birigui

*******************************************************************************/
import java.util.Scanner;
public class Main


{
	public static void main(String[] args) {
	 Scanner ent = new Scanner(System.in);
int periodo;

	 

System.out.println("Em Qual Turno vc Estuda:");
System.out.println("1 para M de MATUTINO");
System.out.println("2 para V de VESPERINO");
System.out.println("3 para N de MATUTINO");
            periodo = ent.nextInt();
    

if(periodo == 1 ){
System.out.println("Bom Dia");
            } else if(periodo == 2){
System.out.println("Boa Tarde");
            } else if(periodo == 3){
System.out.println("Boa Noite");

            
            }
	}
}

