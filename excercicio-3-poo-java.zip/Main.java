/******************************************************************************

Escreva um programa que receba a altura de 10 atletas. 
Esse programa deve imprimir a altura daqueles atletas que tem altura maior que a mC)dia.

*******************************************************************************/
import java.util.Scanner;
import java.util.Arrays;

public class Main
{
  public static void main (String[]args)
  {
    Scanner ent = new Scanner (System.in);

    int alt[] = new int[11];

    int i, media=0,altura=0;


    for (i = 0; i < 10;i++)
      {
	System.out.println ("Infome a aultura do atleta N:" + i);
	alt[i] = ent.nextInt ();
	altura=altura+alt[i];
      }

    media= altura / 10;

   System.out.println("Media = "+media);
   
   
   
   
  }

}
