import java.util.Scanner;
import java.util.Arrays;


public class Classes
{

  public static void entrada (int[]a, int[]b, Scanner ler)
  {

    int i;
    for (i = 0; i < a.length; i++)
      {

	a[i] = ler.nextInt ();
      }

    for (i = 0; i < b.length; i++)
      {

	b[i] = ler.nextInt ();
      }


  }

  public static void imprime (int[]a, int[]b)
  {
    int i;
    System.out.println ("Valores do Vetor 1:\n");
    for (i = 0; i < a.length; i++)
      {
	System.out.println (a[i]);
      }

    System.out.println ("Valores do Vetor 2:\n");
    for (i = 0; i < b.length; i++)
      {
	System.out.println (b[i]);
      }

  }

  public static void soma (int[]a,int[]b,int[]c)
  {
    int i,soma;
     	System.out.println ("Soma");    
 for (i = 0; i < 4; i++){
     
     c[i]=a[i]+b[i];
     
     	System.out.println (c[i]);
     
 }

  }

}
