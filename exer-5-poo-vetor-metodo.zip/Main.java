

/******************************************************************************

 FaC'a um mC)todo que recebe, por parC"metro, 2 vetores de 10 elementos inteiros e que calcule e retorne, 
 tambC)m por parC"metro, o vetor soma dos dois primeiros. 
 Fazer o mC)todo na mesma classe dos mC)todos do exercC-cio 4 e usar para entrada de dados dos 2 vetores, 
 o mC)todo entrada de dados jC! criado para o exercC-cio 4.
*******************************************************************************/
import java.util.Scanner;
import java.util.Arrays;

public class Main
{

  public static void main (String[]args)
  {
    Scanner ler = new Scanner (System.in);
    int[] veta = new int[4];
    int[] vetb = new int[4];
    int[] vetc = new int[4];
    int i;



      System.out.println ("Entre com 20 valores ambos seram dividos em 10 e depois vera a soma deles");
      Classes.entrada (veta,vetb, ler);

      Classes.imprime(veta,vetb);
      
      Classes.soma(veta,vetb,vetc);

  }

}
