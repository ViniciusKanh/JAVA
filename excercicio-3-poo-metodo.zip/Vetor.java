import java.util.Arrays;
import java.util.Scanner;

public class Vetor
{


  public static void vetor (int x)
  {

int v[] = new int [x]; 
            int soma = 0; 
            for(int valor : v){  
                   soma +=  valor; 
            }  
  
            System.out.println("Total: "+soma); 
     } 


  }




