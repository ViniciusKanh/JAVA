/******************************************************************************

Faça um programa que crie um vetor de inteiros de 10 posições, 
leia os valores deste vetor e exiba o vetor na tela ordenado. 
Usar o comando for each neste programa.

*******************************************************************************/
import java.util.Scanner;
import java.util.Arrays;

public class Main
{
  public static void main (String[]args)
  {
    Scanner ent = new Scanner (System.in);

    int vet[] = { 9,3,4,5,7,1,8,10,6,2};
    
    Arrays.sort(vet);
    
    for(int valor:vet)
    System.out.println(valor);
    
    
  }
  
}
