/******************************************************************************

FaC'a um programa que carregue um vetor de dez nC:meros reais, 
calcule e mostre a quantidade de nC:meros negativos e a soma dos nC:meros positivos desse vetor. 
Usar o comando for each neste programa.

*******************************************************************************/
import java.util.Scanner;

public class Main
{
  public static void main (String[]args)
  {
    Scanner ent = new Scanner (System.in);

    int vet[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }, i, sp = 0, sn = 0;



    System.out.println ("Didite os Valores");
    for (i = 0; i < 10; i++)
      {
	vet[i] = ent.nextInt ();

	if (vet[i] > 0)
	  sp = sp + vet[i];
	if (vet[i] < 0)
	  sn = sn + 1;
      }

    System.out.println ("numeros positivos soma = " + sp);
    System.out.println ("numeros negativos quantidade = " + sn);



  }
}
