
import java.util.Scanner;

public class Funcionario {

  String nome;
  float aumento,salario;

  float aumento (String nome, float salario)
  {
    if (salario <= 1500)
      {
	aumento=(this.salario * 25)/100;
	aumento = salario + aumento;
      }
    else if (salario >= 1500 && salario <= 3000)
      {
	aumento = (this.salario * 20) / 100;
	aumento = salario + aumento;
      }
    else if (salario > 3000 && salario <=4500)
      {
	aumento = (this.salario * 20) / 100;
	aumento = salario + aumento;
      }

return salario;
  }
    void mostra (String nome, float salario)
    {


      System.out.println ("Ola Sr(a)" + nome + " \n seu salario passara a ser : " +aumento);
  }
  
  }
