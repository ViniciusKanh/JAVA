/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;

public class Main
{
  public static void main (String[]args)
  {

    Scanner ent = new Scanner (System.in);
    Funcionario c = new Funcionario();

    String nome;
    float salario,Aumento;

      System.out.println ("Digite o nome do funcionario: \n");
      c.nome = ent.nextLine();
      System.out.println ("Digite o salario do mesmo : \n");
      c.salario = ent.nextFloat();
      
      c.aumento(c.nome,c.salario);
      
      
     c.mostra(c.nome,c.salario);


  }
}
