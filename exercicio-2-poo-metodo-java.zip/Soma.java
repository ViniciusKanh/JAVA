public class Soma {



public int valora (int a){

int s;
s=a*2;

return s;



}

public int valorb (int b){

int r;
r=b*2;

return r;



}

public int valorc (int c){

int t;
t=c*2;

return t;



}

}
